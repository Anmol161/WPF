﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iTunes.Models
{
    public class SongsCollection
    {
        public static ObservableCollection<Songs> _dataBaseSongs = new ObservableCollection<Songs>()
        {
            new Songs()
            {
                Title="All I Want for Christmas is You",
                Time="4:01",
                Album="Songs of Inocence",
                Artist="U2",
                Gener="Rock",
                Plays=1

            },
            new Songs()
            {
                Title="new Recording1",
                Time="0:25",
                Album="",
                Artist="U2",
                Gener="Rock",
                Plays=1

            },
             new Songs()
            {
                Title="new Recording2",
                Time="0:33",
                Album="",
                Artist="",
                Gener="Rock",
                Plays=1

            },
              new Songs()
            {
                Title="new Recording3",
                Time="4:01",
                Album="",
                Artist="U2",
                Gener="",
                Plays=1

            },
               new Songs()
            {
                Title="new Recording4",
                Time="0:19",
                Album="Songs of Inocence",
                Artist="U2",
                Gener="Rock",
                Plays=1

            },
                   new Songs()
            {
                Title="new Recording0",
                Time="0:19",
                Album="Songs of Inocence",
                Artist="U2",
                Gener="Rock",
                Plays=1

            },
                         new Songs()
            {
                Title="check",
                Time="0:19",
                Album="Songs of Inocence",
                Artist="U2",
                Gener="Rock",
                Plays=1

            },



        };

        public static  ObservableCollection<Songs> GetSongs()
        {
            return _dataBaseSongs;
        }
        public static void AddSongs(Songs songs)
        {
             _dataBaseSongs.Add(songs);
        }
    }
}
