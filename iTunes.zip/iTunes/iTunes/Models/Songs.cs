﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iTunes.Models
{
    public class Songs
    {


        public Songs()
        {
            
        }
        public string Id { get; set; }
        public String Title { get; set; }
        public string Time { get; set; }
        public string Artist { get; set; }
        public string Album { get; set; }
        public string Gener { get; set; }
        public int Plays { get; set; }

    }
}
