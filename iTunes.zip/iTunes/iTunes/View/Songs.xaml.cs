﻿using iTunes.Models;
using iTunes.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using iTunes.Models;

namespace iTunes.View
{
    /// <summary>
    /// Interaction logic for Songs.xaml
    /// </summary>
    public partial class Songs : UserControl
    {
        NavigationVM Nvm;
        
        public Songs()
        {
            InitializeComponent();
            Nvm=new NavigationVM();
            //base.DataContext = Nvm;
            
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PlayList_Click(object sender, RoutedEventArgs e)
        {
            MenuItem playListMenu= (MenuItem)sender;
           // playListMenu.Items.Clear();
           // playListMenu.Items.Add();
        }
        private void PlayNext_Click(object sender, RoutedEventArgs e)
        {

        }
        private void PlayLater_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void SongList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string slectedSongTitle = (string)SongList.SelectedValue;
            
            Nvm.SelectedItems(slectedSongTitle);
        }
    }
}
