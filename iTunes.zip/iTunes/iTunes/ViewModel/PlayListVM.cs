﻿using iTunes.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iTunes.ViewModel
{
    class PlayListVM
    {
        public ObservableCollection<Songs> PlayListSongs { get; set; }
        SongsVM SongsVM=new SongsVM();
        public PlayListVM()
        {
             PlayListSongs = SongsCollection.GetSongs();
            //PlayListSongs = SongsVM.AddToPlayList();
           // PlayListSongs=SongsVM.GetPLayList();
            
        }
    }
}
