﻿using iTunes.Models;
using iTunes.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace iTunes.ViewModel
{
    class NavigationVM:ViewModelBase
    {
        private object _currentView;
        //private string _title;
        //public string Title
        //{
        //    get { return _title; }
        //    set
        //    {
        //        _title = value;
        //        OnPropertyChanged(nameof(Title));
        //    }
        //    }
        private string _txtSelectedItem;
        public string txtSelectedItem { 
            get=>_txtSelectedItem;
            set { 
                _txtSelectedItem = value;
                OnPropertyChanged(nameof(txtSelectedItem));
                    }
        }
        public Object CurrentView { 
            get { return _currentView; }
            set { _currentView = value; OnPropertyChanged(); }
        }

        public ICommand SongCommand { get; set; }
        public ICommand PlayListViewCommand { get; set; }
        private void Songs (object obj)=>CurrentView=new SongsVM();
        private void PlayListView(object obj)=>CurrentView=new PlayListVM();

        public NavigationVM()
        {
            SongCommand = new RelayCommand(Songs);
            PlayListViewCommand = new RelayCommand(PlayListView);
            //startup page
            //RecentlyAdded = new RecentlyAddedVM();
        }

        public void SelectedItems(string songTitle)
        {
            txtSelectedItem=songTitle;
            OnPropertyChanged("txtSelectedItem");
        }
    }
}
